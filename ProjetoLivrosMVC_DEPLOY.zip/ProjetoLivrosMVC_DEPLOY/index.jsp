<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Catálogo de livros</title>
<link rel="stylesheet" type="text/css" href="css/estilo.css">
</head>
<body>
	<h1>📚Bem-vindo à Biblioteca de Fabio Sousa Leal📚</h1>
    <p>Selecione uma opção:</p>

    <div class="menu-botoes">
        <a href="LivroServlet?acao=listar">Consultar Livros</a>
        <a href="formulario.jsp">Cadastrar Livro</a>
        <a href="buscar.jsp">Procurar Livro</a>
        
    </div>
</body>
</html>